import LoginData from './datas/login.json'

export {
  LoginData
}
